-- phpMyAdmin SQL Dump
-- version 3.4.11.1deb2
-- http://www.phpmyadmin.net
--
-- Host: localhost
-- Generation Time: Apr 09, 2014 at 12:30 AM
-- Server version: 5.5.35
-- PHP Version: 5.4.4-14+deb7u8

SET SQL_MODE="NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Database: `theapp`
--

-- --------------------------------------------------------

--
-- Table structure for table `brands`
--

CREATE TABLE IF NOT EXISTS `brands` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(100) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=5 ;

--
-- Dumping data for table `brands`
--

INSERT INTO `brands` (`id`, `name`) VALUES
(1, 'Apple'),
(2, 'Nokia'),
(3, 'HP'),
(4, 'Assus');

-- --------------------------------------------------------

--
-- Table structure for table `devices`
--

CREATE TABLE IF NOT EXISTS `devices` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `brand_id` int(11) NOT NULL,
  `model` varchar(50) DEFAULT NULL,
  `custody_from` datetime DEFAULT NULL,
  `custody_till` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `fk_devices_brands1_idx` (`brand_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=4 ;

--
-- Dumping data for table `devices`
--

INSERT INTO `devices` (`id`, `brand_id`, `model`, `custody_from`, `custody_till`) VALUES
(1, 1, 'iMac', '2014-04-23 10:43:11', '2014-12-23 22:43:11'),
(2, 1, 'iPhone 4s', '2013-12-23 10:43:11', '2016-12-23 10:43:11'),
(3, 2, 'lumia 520', '2014-01-23 10:43:11', '2014-06-23 10:43:11');

-- --------------------------------------------------------

--
-- Table structure for table `team_members`
--

CREATE TABLE IF NOT EXISTS `team_members` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `first_name` varchar(255) DEFAULT NULL,
  `last_name` varchar(255) DEFAULT NULL,
  `email` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=6 ;

--
-- Dumping data for table `team_members`
--

INSERT INTO `team_members` (`id`, `first_name`, `last_name`, `email`) VALUES
(1, 'Razvan', 'Posobescu', 'razvanposobescu@gmail.com'),
(2, 'Vasile', 'Popa', 'vasile.popa@email.com'),
(3, 'Alexandru', 'Popescu', 'alexpopescu@gmial.com'),
(4, 'Andrei', 'Balan', 'andreibalan@yahoo.com'),
(5, 'Lucian', 'Miere', 'miere@lucimiere.ro');

-- --------------------------------------------------------

--
-- Table structure for table `team_member_devices`
--

CREATE TABLE IF NOT EXISTS `team_member_devices` (
  `team_member_id` int(11) NOT NULL,
  `device_id` int(11) NOT NULL,
  PRIMARY KEY (`team_member_id`,`device_id`),
  KEY `fk_team_member_id` (`device_id`),
  KEY `fk_devices_id` (`team_member_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `team_member_devices`
--

INSERT INTO `team_member_devices` (`team_member_id`, `device_id`) VALUES
(1, 1),
(2, 1),
(4, 1),
(1, 2),
(2, 2),
(1, 3),
(3, 3);

--
-- Constraints for dumped tables
--

--
-- Constraints for table `devices`
--
ALTER TABLE `devices`
  ADD CONSTRAINT `fk_devices_brands1` FOREIGN KEY (`brand_id`) REFERENCES `brands` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION;

--
-- Constraints for table `team_member_devices`
--
ALTER TABLE `team_member_devices`
  ADD CONSTRAINT `fk_team_member` FOREIGN KEY (`team_member_id`) REFERENCES `team_members` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  ADD CONSTRAINT `fk_device` FOREIGN KEY (`device_id`) REFERENCES `devices` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
